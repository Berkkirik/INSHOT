export const Images = {
  woman: require("./woman.png"),
  man: require("./man.png"),
  other: require("./other.png"),
  check: require("./check.png"),
};
