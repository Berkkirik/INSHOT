import NavigationStack from './Main';
export default NavigationStack;
