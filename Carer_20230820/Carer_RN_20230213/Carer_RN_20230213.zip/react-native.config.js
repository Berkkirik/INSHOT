module.exports = {
  assets: ['./src/fonts/'],
};
