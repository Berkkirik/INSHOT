const FONTS_APP = {
  Hind: {
    Bold: "Hind-Bold",
    SemiBold: "Hind-SemiBold",
    Regular: "Hind-Regular",
    Medium: "Hind-Medium",
    Light: "Hind-Light",
  },
};
const HIND = FONTS_APP.Hind;

export default { HIND };
