import React, {useCallback} from 'react';
import {StyleSheet, TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import SvgBackArrow from '@svgs/SvgBackArrow';

interface ButtonHeaderProps {
  children?: JSX.Element;
  onPress?(): void;
}

const ButtonHeader = ({children, onPress}: ButtonHeaderProps) => {
  const navigation = useNavigation();

  const onPressButton = useCallback(() => {
    if (onPress) {
      onPress();
    } else {
      navigation.goBack();
    }
  }, [navigation]);

  return (
    <TouchableOpacity style={styles.button} onPress={onPressButton}>
      {children ? children : <SvgBackArrow />}
    </TouchableOpacity>
  );
};
export default ButtonHeader;

const styles = StyleSheet.create({
  button: {
    width: 50,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
