import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  Animated,
  TouchableOpacity,
  StyleProp,
  ViewStyle,
  ImageRequireSource,
  TouchableWithoutFeedback,
} from 'react-native';
import colors from '@utils/colors';
import FONTS from '@utils/fonts';
import SvgLocation from '@svgs/SvgLocation';
import SvgStar from '@svgs/AppointmentList/SvgStar';
import ButtonPrimary from '@components/ButtonPrimary';
import Swipeable from 'react-native-gesture-handler/Swipeable';
import SvgDelete from '@svgs/SvgDelete';
import {ConfirmDialog} from 'react-native-simple-dialogs';

interface DoctorItemProps {
  style?: StyleProp<ViewStyle>;
  imgDoctor: ImageRequireSource;
  doctorName: string;
  specialized: string;
  rating: string;
  location: string;
  onCall?(): void;
  onMessage?(): void;
  activeRemove: boolean;
  onPress?(): void;
  onLocation?(): void;
}

const DoctorItem = (props: DoctorItemProps) => {
  const {
    style,
    imgDoctor,
    doctorName,
    specialized,
    rating,
    location,
    onCall,
    onMessage,
    activeRemove,
    onPress,
    onLocation,
  } = props;
  const swipeableRef = React.useRef<Swipeable>(null);
  const [visible, setVisible] = React.useState(false);

  const closeSwipeable = () => {
    swipeableRef.current?.close();
  };
  const onCloseDialog = () => {
    setVisible(false);
    closeSwipeable();
  };
  const buttonDelete = (
    color: string,
    backgroundColor: string,
    x: number,
    progressAnimatedValue: Animated.AnimatedInterpolation<string | number>,
  ) => {
    const trans = progressAnimatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [x, 0],
    });

    return (
      <Animated.View
        style={[styles.btnDeleteView, {transform: [{translateX: trans}]}]}>
        <SvgDelete />
      </Animated.View>
    );
  };

  const renderRightActions = (
    progressAnimatedValue: Animated.AnimatedInterpolation<string | number>,
    dragAnimatedValue: Animated.AnimatedInterpolation<string | number>,
    swipeable: Swipeable,
  ) => {
    if (activeRemove) {
      return (
        <TouchableOpacity
          onPress={() => {
            setVisible(true);
          }}
          activeOpacity={0.6}
          style={styles.buttonStyle}>
          {buttonDelete('#000000', '#eeeeee', 96, progressAnimatedValue)}
        </TouchableOpacity>
      );
    }
  };

  const deleteDoctor = () => {
    onCloseDialog();
    closeSwipeable();
  };

  return (
    <>
      <TouchableWithoutFeedback
        onPress={() => {
          swipeableRef.current?.close();
        }}>
        <Swipeable
          ref={swipeableRef}
          rightThreshold={40}
          renderRightActions={renderRightActions}>
          {/* // renderRightActions={RenderRightActions}> */}
          <TouchableOpacity
            onPress={onPress}
            activeOpacity={0.6}
            style={[styles.doctorItem, style]}>
            <Image style={styles.imgDoctor} source={imgDoctor} />
            <View style={styles.rateView}>
              <Text style={styles.txtDoctorName}>{doctorName}</Text>
              <View style={styles.setRow}>
                <SvgStar style={styles.svgStart} />
                <Text style={styles.txtRating}>{rating}</Text>
              </View>
            </View>
            <Text style={styles.txtSpecialized}>{specialized}</Text>
            <TouchableOpacity
              onPress={onLocation}
              activeOpacity={0.6}
              style={styles.locationView}>
              <SvgLocation color={colors.dimGray} />
              <Text style={styles.txtLocation}> {location}</Text>
            </TouchableOpacity>
            <View style={styles.btnView}>
              <ButtonPrimary
                style={styles.btnCall}
                title={'Call'}
                titleStyle={styles.txtBtnCall}
                onPress={onCall}
              />
              <ButtonPrimary
                style={styles.btnMessage}
                titleStyle={styles.txtBtnMessage}
                title={'Message'}
                onPress={onMessage}
              />
            </View>
          </TouchableOpacity>
        </Swipeable>
      </TouchableWithoutFeedback>
      <ConfirmDialog
        dialogStyle={styles.dialogStyle}
        title={`Delete Doctor`}
        message={`Do you want delete doctor ${doctorName} on list?`}
        visible={visible}
        messageStyle={styles.messageStyle}
        onTouchOutside={onCloseDialog}
        positiveButton={{
          title: 'Done',
          onPress: deleteDoctor,
          style: styles.positiveButton,
          titleStyle: styles.txtPositiveButton,
        }}
        negativeButton={{
          title: 'Cancel',
          onPress: onCloseDialog,
          style: styles.negativeButton,
          titleStyle: styles.txtNegativeButton,
        }}
      />
    </>
  );
};

export default DoctorItem;

const styles = StyleSheet.create({
  doctorItem: {
    paddingVertical: 16,
    backgroundColor: colors.white,
    borderRadius: 12,
    paddingLeft: 88,
    paddingRight: 16,
    height: 141,
    flex: 1,
    marginBottom: 16,
    marginLeft: 24,
  },
  imgDoctor: {
    width: 56,
    height: 56,
    borderRadius: 56,
    overflow: 'hidden',
    position: 'absolute',
    top: 16,
    left: 16,
  },
  txtDoctorName: {
    fontFamily: FONTS.HIND.Regular,
    fontSize: 16,
    lineHeight: 24,
    fontWeight: '500',
    color: colors.semiBlack,
    textTransform: 'uppercase',
  },
  txtSpecialized: {
    fontFamily: FONTS.HIND.Regular,
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
    color: colors.silverChalice,
    marginTop: 4,
    marginBottom: 4,
  },
  locationView: {
    flexDirection: 'row',
    height: 26,
  },
  txtLocation: {
    fontFamily: FONTS.HIND.Regular,
    fontSize: 14,
    lineHeight: 20,
    color: colors.brown1,
    marginBottom: -6,
    marginLeft: 4,
  },
  txtRating: {
    fontFamily: FONTS.HIND.Regular,
    fontSize: 14,
    lineHeight: 21,
    color: colors.orange,
  },
  rateView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  setRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: -1,
  },
  svgStart: {
    marginBottom: 1,
    marginRight: 5,
  },
  btnView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  btnCall: {
    flex: 1,
    height: 32,
    backgroundColor: colors.pageBackGround,
    marginRight: 16,
  },
  txtBtnCall: {
    fontFamily: FONTS.HIND.Regular,
    fontWeight: '400',
    textTransform: 'capitalize',
    color: colors.silverChalice,
    fontSize: 14,
  },
  btnMessage: {
    flex: 1,
    height: 32,
    backgroundColor: colors.secondBlueOpacity,
  },
  txtBtnMessage: {
    fontWeight: '500',
    textTransform: 'capitalize',
    color: colors.secondBlue,
    fontSize: 14,
  },
  btnDeleteView: {
    flex: 1,
    backgroundColor: colors.secondRed,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonStyle: {
    width: 96,
    height: 141,
  },
  dialogStyle: {
    width: 340,
    height: 200,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: colors.white,
    shadowOffset: {width: 0, height: 2},
    shadowRadius: 25,
    shadowColor: 'rgba(0, 0, 0, 0.1)',
    shadowOpacity: 0.1,
    justifyContent: 'space-between',
  },
  messageStyle: {
    fontFamily: FONTS.HIND.Regular,
    fontSize: 16,
    lineHeight: 24,
    color: colors.dimGray,
    textAlign: 'center',
    marginHorizontal: 50,
  },
  positiveButton: {
    backgroundColor: colors.white,
    height: 55,
  },
  txtPositiveButton: {
    fontFamily: FONTS.HIND.SemiBold,
    fontSize: 14,
    color: colors.classicBlue,
    textAlign: 'center',
  },
  txtNegativeButton: {
    fontFamily: FONTS.HIND.SemiBold,
    fontSize: 14,
    color: colors.white,
    textAlign: 'center',
  },
  negativeButton: {
    backgroundColor: colors.classicBlue,
    height: 55,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
