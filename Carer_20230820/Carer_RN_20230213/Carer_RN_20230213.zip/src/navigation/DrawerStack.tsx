import React, {memo} from 'react';
import {StyleSheet} from 'react-native';
import Animated, {
  interpolate,
  Easing,
  useSharedValue,
  withTiming,
  useAnimatedStyle,
} from 'react-native-reanimated';
import {useDrawerStatus} from '@react-navigation/drawer';

import {createStackNavigator} from '@react-navigation/stack';
import ROUTES from '@utils/routes';
import MainBottomTab from '@navigation/MainBottomTab';

const Stack = createStackNavigator();

const DrawerStack = memo(() => {
  const isDrawerVisible = useDrawerStatus();
  const AniValue = useSharedValue(0);

  React.useEffect(() => {
    if (isDrawerVisible === 'open') {
      AniValue.value = withTiming(1);
    } else {
      AniValue.value = withTiming(0);
    }
  }, [isDrawerVisible, AniValue]);
  const animatedStyle = useAnimatedStyle(() => {
    let input = [0, 1];
    let duration = {duration: 250, easing: Easing.exp};
    const scale = interpolate(AniValue.value, input, [1, 0.82]);
    const moveX = interpolate(AniValue.value, input, [0, 340]);
    const borderWidth = interpolate(AniValue.value, input, [0, 10]);
    const borderRadius = interpolate(AniValue.value, input, [0, 16]);
    return {
      flex: 1,
      transform: [{scale: withTiming(scale, duration)}, {translateX: moveX}],
      borderWidth: withTiming(borderWidth, duration),
      borderRadius: withTiming(borderRadius, duration),
      borderColor: '#FFFFFF',
      ...StyleSheet.flatten,
    };
  });
  return (
    <Animated.View style={animatedStyle}>
      <Stack.Navigator screenOptions={{headerTransparent: true}}>
        <Stack.Screen
          options={{headerShown: false}}
          name={ROUTES.MainBottomTab}
          component={MainBottomTab}
        />
      </Stack.Navigator>
    </Animated.View>
  );
});

export default DrawerStack;

const styles = StyleSheet.create({
  drawerStack: {
    flex: 1,
  },
});
