import React, {memo} from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import colors from '@utils/colors';
import FONTS from '@utils/fonts/index';

import ROUTES from '@utils/routes';
import Upcoming from '@screens/Upcoming';
import Past from '@screens/Past';
import {
  BottomTabNavigationOptions,
  LabelPosition,
} from '@react-navigation/bottom-tabs/lib/typescript/src/types';
import {View, Text, StyleSheet} from 'react-native';
import {
  useSafeAreaInsets,
  useSafeAreaFrame,
} from 'react-native-safe-area-context';
import SvgBackArrow from '@svgs/SvgBackArrow';
import {useNavigation} from '@react-navigation/native';
import SvgCalendar from '@svgs/MainPage/SvgCalendar';
import ButtonHeader from '@components/ButtonHeader';
const Tab = createBottomTabNavigator();

const AppointmentListTab = memo(
  ({upcoming, past}: {upcoming: number; past: number}) => {
    const {goBack} = useNavigation();
    const {top} = useSafeAreaInsets();
    const {width} = useSafeAreaFrame();

    const ScreenOptions: BottomTabNavigationOptions = {
      headerTitleStyle: {
        color: colors.white,
        fontFamily: FONTS.HIND.Regular,
        fontWeight: '500',
        fontSize: 16,
        lineHeight: 20,
      },
      headerLeft: props => (
        <ButtonHeader
          children={<SvgBackArrow color={colors.white} />}
          onPress={goBack}
        />
      ),
      headerRight: props => (
        <ButtonHeader
          children={<SvgCalendar color={colors.white} />}
          onPress={goBack}
        />
      ),
      headerBackground: () => {
        return (
          <View
            style={{
              backgroundColor: colors.blue,
              width: width,
              height: 84,
            }}
          />
        );
      },
      headerTitle: 'Appoinment',
      tabBarActiveTintColor: colors.white,
      tabBarInactiveTintColor: colors.dimGray,
      tabBarIconStyle: {
        width: 0,
        height: 0,
        position: 'absolute',
        opacity: 0,
      },
      tabBarStyle: {
        borderRadius: 40,
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: 24,
        marginTop: top + 58,
        position: 'absolute',
        top: 0,
        height: 40,
        backgroundColor: colors.white,
        borderWidth: 0,
        shadowColor: colors.black,
        shadowOpacity: 0.1,
        shadowOffset: {
          width: 4,
          height: 4,
        },
        shadowRadius: 12,
      },
      tabBarLabel: (props: {
        focused: boolean;
        color: string;
        position: LabelPosition;
        children: string;
      }) => {
        return (
          <View
            style={{
              backgroundColor: props.focused ? colors.blue : colors.white,
              position: 'absolute',
              bottom: -30,
              height: 38,
              width: (width - 48) / 2,
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: 40,
            }}>
            <Text
              style={{
                fontFamily: FONTS.HIND.Regular,
                fontWeight: '700',
                fontSize: 13,
                color: props.focused ? colors.white : colors.black,
              }}>
              {props.children}
              {upcoming > 0 && props.children === 'Upcoming' && (
                <View style={styles.note}>
                  <Text>{props.children}</Text>
                </View>
              )}
            </Text>
          </View>
        );
      },
    };
    return (
      <Tab.Navigator
        initialRouteName={ROUTES.UpComing}
        screenOptions={ScreenOptions}>
        <Tab.Screen
          name={ROUTES.UpComing}
          component={Upcoming}
          options={{title: 'Upcoming'}}
        />
        <Tab.Screen
          name={ROUTES.Past}
          component={Past}
          options={{title: 'Past'}}
        />
      </Tab.Navigator>
    );
  },
);
export default AppointmentListTab;
const styles = StyleSheet.create({
  note: {},
});
