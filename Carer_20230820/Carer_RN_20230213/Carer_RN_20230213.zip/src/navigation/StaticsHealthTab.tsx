import React from 'react';
import colors from '@utils/colors';
import FONTS from '@utils/fonts/index';
import ROUTES from '@utils/routes';
import Day from '@screens/Day';
import Month from '@screens/Month';
import Year from '@screens/Year';
import Week from '@screens/Week';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import {
  useSafeAreaFrame,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';
import {LabelPosition} from '@react-navigation/bottom-tabs/lib/typescript/src/types';
import {View, Text} from 'react-native';
const Tab = createMaterialTopTabNavigator();

export default function MaterialTopTabNavigator() {
  const {top} = useSafeAreaInsets();
  const {width} = useSafeAreaFrame();
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarShowIcon: false,
        tabBarIndicator: () => null,
        tabBarShowLabel: true,
        tabBarStyle: {
          borderRadius: 40,
          justifyContent: 'center',
          alignItems: 'center',
          marginHorizontal: 24,
          marginTop: top + 58,
          // position: 'absolute',
          // top: 0,
          zIndex: 1000,
          height: 40,
          backgroundColor: colors.white,
          borderWidth: 0,
          shadowColor: colors.black,
          shadowOpacity: 0.1,
          shadowOffset: {
            width: 4,
            height: 4,
          },
          shadowRadius: 12,
        },
        lazy: true,
        tabBarLabelStyle: {
          fontFamily: FONTS.HIND.Regular,
          fontWeight: '700',
          fontSize: 13,
        },
        tabBarLabel: (props: {
          focused: boolean;
          color: string;
          children: string;
        }) => {
          return (
            <View
              style={{
                backgroundColor: props.focused ? colors.blue : colors.black,
                // position: 'absolute',
                // bottom: -30,
                height: 38,
                width: (width - 48) / 3,
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: 40,
              }}>
              <Text
                style={{
                  fontFamily: FONTS.HIND.Regular,
                  fontWeight: '700',
                  fontSize: 13,
                  color: props.focused ? colors.blue : colors.black,
                }}>
                {props.children}
              </Text>
            </View>
          );
        },
      }}>
      <Tab.Screen name={ROUTES.Day} component={Day} options={{title: 'Day'}} />
      <Tab.Screen
        name={ROUTES.Week}
        component={Week}
        options={{title: 'Week'}}
      />
      <Tab.Screen
        name={ROUTES.Month}
        component={Month}
        options={{title: 'Month'}}
      />
      <Tab.Screen
        name={ROUTES.Year}
        component={Year}
        options={{title: 'Year'}}
      />
    </Tab.Navigator>
  );
}
