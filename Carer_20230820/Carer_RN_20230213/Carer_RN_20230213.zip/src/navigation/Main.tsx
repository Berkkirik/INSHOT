import React, {memo} from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {navigationRef} from './NavigationService';
import SvgNotification from '@svgs/SvgNotification';
import SvgSetting from '@svgs/SvgSetting';
import SvgMap from '@svgs/SvgMap';
import SvgBookMark from '@svgs/SvgBookMark';
import SvgCalendar from '@svgs/SvgCalendar';
import SvgMyHeart from '@svgs/DoctorInformation/SvgMyHeart';
import SvgAdd from '@svgs/SvgAdd';
import SvgSearch from '@svgs/SvgSearch';
import HeaderTitle from '@components/HeaderTittle';
import ButtonHeader from '@components/ButtonHeader';
import HeaderBackGround from '@components/HeaderBackGround';
import WalkThrough from '@screens/WalkThrough';
import SignIn from '@screens/SignIn';
import SignUp from '@screens/SignUp';
import ForgotPassword from '@screens/ForgotPassword';
import ResetPassword from '@screens/ResetPassword';
import ResetPasswordSuccess from '@screens/ResetPasswordSuccess';
import VerifyEmail from '@screens/VerifyEmail';
import VerifyMobile from '@screens/VerifyMobie';
import CreateAccount from '@screens/CreateAccount';
import FullName from '@screens/FullName';
import Gender from '@screens/Gender';
import BirthDay from '@screens/BirthDay';
import Weight from '@screens/Weight';
import Height from '@screens/Height';
import Blood from '@screens/Blood';
import PricePlan from '@screens/PricePlan';
import Menu from '@screens/Menu';
import AppointmentList from '@screens/AppointmentList';
import AppointmentCalendar from '@screens/AppointmentCalendar';
import BookAppointment from '@screens/BookAppointment';
import AppointmentDetails from '@screens/AppointmentDetails';
import IndicatorsSettingsTab from '@navigation/IndicatorsSettingsTab';
import InputTestIndicators from '@screens/InputTestIndicators';
import SetGoal from '@screens/SetGoal';
import MapsDoctors from '@screens/MapsDoctors';
import DoctorProfile from '@screens/DoctorProfile';
import DoctorInformation from '@screens/DoctorInformation';
import DoctorAddress from '@screens/DoctorAddress';
import DoctorReview from '@screens/DoctorReview';
import GoalSettings from '@screens/GoalSettings';
import NewsTab from '@navigation/NewsTab';
import NewsBookmark from '@screens/NewsBookmark';
import FindDoctors from '@screens/FindDoctors';
import ResultFindDoctor from '@screens/ResultFindDoctor';
import AddDrugs from '@screens/AddDrugs';
import DrugDetails from '@screens/DrugDetails';
import DrugShop from '@screens/DrugShop';
import DrugShopDetails from '@screens/DrugShopDetails';
import NewsComment from '@screens/NewsComment';
import Cart from '@screens/Cart';
import Billing from '@screens/Billing';
import Insurance from '@screens/Insurance';
import ListDrugs from '@screens/ListDrugs';
import FindHospital from '@screens/FindHospital';
import CreateAppointment from '@screens/CreateAppointment';
import Services from '@screens/Services';
import DashBoard from '@screens/DashBoard';
import DoctorMessage from '@screens/DoctorMessage';
import NewsDetails from '@screens/NewDetails';
import VideoCall from '@screens/VideoCall';
import CallDoctor from '@screens/CallDoctor';
import Notification from '@screens/Notification';
import DrawerNavigator from '@navigation/DrawerNavigator';
import SvgDelete from '@svgs/ForgotPassword/SvgDelete';
import ROUTES from '@utils/routes';
import {RootStackParamsList} from './type-navigation';

const Stack = createStackNavigator<RootStackParamsList>();

const Main = memo(() => {
  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator
        initialRouteName={'WalkThrough'}
        screenOptions={{headerShown: false}}>
        <Stack.Screen
          name={'WalkThrough'}
          component={WalkThrough}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'DrawerNavigator'}
          component={DrawerNavigator}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'SignIn'}
          component={SignIn}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'SignUp'}
          component={SignUp}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'ForgotPassword'}
          component={ForgotPassword}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'ResetPassword'}
          component={ResetPassword}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'ResetPasswordSuccess'}
          component={ResetPasswordSuccess}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'VerifyEmail'}
          component={VerifyEmail}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'VerifyMobile'}
          component={VerifyMobile}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'CreatAccount'}
          component={CreateAccount}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'Notification'}
          component={Notification}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'DoctorMessage'}
          component={DoctorMessage}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'NewsDetails'}
          component={NewsDetails}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'VideoCall'}
          component={VideoCall}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'CallDoctor'}
          component={CallDoctor}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'Menu'}
          component={Menu}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'AppointmentCalendar'}
          component={AppointmentCalendar}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title="AppointmentCalendar" />,
            headerLeft: () => <ButtonHeader children={<SvgDelete />} />,
            headerBackground: () => <HeaderBackGround border={false} />,
          }}
        />
        <Stack.Screen
          name={'DoctorProfile'}
          component={DoctorProfile}
          options={{headerShown: false}}
        />
        <Stack.Screen
          name={'Services'}
          component={Services}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Services'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'DashBoard'}
          component={DashBoard}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'DashBoard'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'FullName'}
          component={FullName}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Fullname'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'Gender'}
          component={Gender}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Your Gender'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'BirthDay'}
          component={BirthDay}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Your Birthday'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'Weight'}
          component={Weight}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Your Weight'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'Height'}
          component={Height}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Your Height'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'Blood'}
          component={Blood}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Blood'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'AppointmentList'}
          component={AppointmentList}
          options={({navigation}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Appoinment'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader
                children={<SvgCalendar />}
                onPress={() => {
                  navigation.navigate(AppointmentCalendar);
                }}
              />
            ),
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'IndicatorsSettings'}
          component={IndicatorsSettingsTab}
          options={() => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Settings'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader children={<SvgSetting />} onPress={() => {}} />
            ),
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'News'}
          component={NewsTab}
          options={({navigation}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'News Healthy'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader
                children={<SvgBookMark />}
                onPress={() => {
                  navigation.navigate(NewsBookmark);
                }}
              />
            ),
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'CreateAppointment'}
          component={CreateAppointment}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Create Appointment'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'InputTestIndicators'}
          component={InputTestIndicators}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Weight'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader children={<SvgSetting />} onPress={() => {}} />
            ),
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'SetGoal'}
          component={SetGoal}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Goal Weight'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'DoctorInformation'}
          component={DoctorInformation}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Doctor Information'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader children={<SvgMyHeart />} onPress={() => {}} />
            ),
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'DoctorAddress'}
          component={DoctorAddress}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Working Address'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'DoctorReview'}
          component={DoctorReview}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Review'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'NewsBookmark'}
          component={NewsBookmark}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Bookmarks'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'GoalSettings'}
          component={GoalSettings}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Goals Settings'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader children={<SvgSetting />} onPress={() => {}} />
            ),
            headerBackground: () => <HeaderBackGround />,
          }}
        />

        <Stack.Screen
          name={'AppointmentDetails'}
          component={AppointmentDetails}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Appointment Details'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'BookAppointment'}
          component={BookAppointment}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Book Appoinment'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'FindDoctors'}
          component={FindDoctors}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Find Doctors'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'ResultFindDoctor'}
          component={ResultFindDoctor}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Result'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader children={<SvgMap />} onPress={() => {}} />
            ),
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'AddDrugs'}
          component={AddDrugs}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Add Drugs'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'DrugDetails'}
          component={DrugDetails}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Drug Details'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'DrugShop'}
          component={DrugShop}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Drugs Shop'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'DrugShopDetails'}
          component={DrugShopDetails}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Shop Details'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'NewsComment'}
          component={NewsComment}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Comments'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'Cart'}
          component={Cart}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Shopping Cart'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'Billing'}
          component={Billing}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Billing'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader children={<SvgMap />} onPress={() => {}} />
            ),
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'MapsDoctors'}
          component={MapsDoctors}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Maps'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader children={<SvgMap />} onPress={() => {}} />
            ),
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'Insurance'}
          component={Insurance}
          options={({}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Insurance'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader children={<SvgSearch />} onPress={() => {}} />
            ),
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'ListDrugs'}
          component={ListDrugs}
          options={({navigation}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Pills Library'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader
                children={<SvgAdd />}
                onPress={() => {
                  navigation.navigate(AddDrugs);
                }}
              />
            ),
            headerBackground: () => <HeaderBackGround />,
          })}
        />
        <Stack.Screen
          name={'FindHospital'}
          component={FindHospital}
          options={{
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Find Hospital'} />,
            headerLeft: () => <ButtonHeader />,
            headerBackground: () => <HeaderBackGround />,
          }}
        />
        <Stack.Screen
          name={'PricePlan'}
          component={PricePlan}
          options={({navigation}) => ({
            headerTitleAlign: 'center',
            headerTitle: () => <HeaderTitle title={'Choose your Plan'} />,
            headerLeft: () => <ButtonHeader />,
            headerRight: () => (
              <ButtonHeader
                children={<SvgNotification />}
                onPress={() => {
                  navigation.navigate(Notification);
                }}
              />
            ),
            headerBackground: () => <HeaderBackGround />,
          })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
});

export default Main;
