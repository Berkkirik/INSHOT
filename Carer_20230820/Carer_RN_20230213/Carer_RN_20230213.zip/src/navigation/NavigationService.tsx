import {
  NavigationAction,
  NavigationContainerRef,
} from '@react-navigation/native';
import React from 'react';

const navigationRef =
  React.createRef<NavigationContainerRef<ReactNavigation.RootParamList>>();
const isMountedRef = React.createRef();

const navigate = (name: never, params: never) => {
  navigationRef?.current?.navigate(name, params);
};

const dispatch = (action: NavigationAction) => {
  navigationRef?.current?.dispatch(action);
};

export {navigationRef, isMountedRef, navigate, dispatch};
