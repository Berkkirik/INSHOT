/* App config for images
 */
const images = {
  icons: {
    //logo: require('../assets/images/icons/logo.png'),
  },
};

export default images;
