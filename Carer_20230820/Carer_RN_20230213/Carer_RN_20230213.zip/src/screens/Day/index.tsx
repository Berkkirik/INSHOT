import React, {memo, useCallback, useState, useRef} from 'react';
import {Animated, Platform, ScrollView} from 'react-native';
import {ScaledSheet} from 'react-native-size-matters';
import colors from '@utils/colors';
import StaticsHealthItem from '@screens/Day/Components/StaticsHealthItem';
import SvgNurse from '@svgs/SvgNurse';
import StaticsHealthChart from '@components/StaticsHealthChart';
import {getStatusBarHeight} from 'react-native-iphone-x-helper';
import SvgBlood from '@svgs/Blood/SvgBlood';
import SvgScale from '@svgs/SvgScale';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import useAppNavigation from '@hooks/useAppNavigation';

const NOTIFICATION_DATA = {
  title: 'Good Health 👍',
  description: 'Keep track it everyday!',
  Svg: <SvgNurse width={90} height={90} />,
};

const Day = memo(({}) => {
  const {navigate} = useAppNavigation();
  const {top} = useSafeAreaInsets();
  const [notificationData, setNotificationData] = useState(NOTIFICATION_DATA);
  const [viewState, setViewState] = useState(false);
  const [view, setView] = useState(false);
  const [showChart1, setShowChart1] = useState(true);
  const [showChart2, setShowChart2] = useState(true);
  const opacityAnim = useRef(new Animated.Value(1)).current;
  const opacityAnim1 = useRef(new Animated.Value(1)).current;

  const opacityStyle = {
    opacity: opacityAnim,
  };

  const onChart1 = useCallback(() => {
    startAnimationOpacity();
    setViewState(!viewState);
    viewState === false ? setShowChart2(false) : setShowChart2(true);
  }, [viewState]);

  const onChart2 = useCallback(() => {
    startAnimationOpacity1();
    setView(!view);
    view === false ? setShowChart1(false) : setShowChart1(true);
  }, [view]);

  const onSeeGoals = useCallback(() => {
    navigate('GoalSettings');
  }, []);

  const onEditGoal = useCallback(() => {
    navigate('SetGoal');
  }, []);

  const startAnimationOpacity = useCallback(() => {
    if (viewState === true) {
      Animated.timing(opacityAnim, {
        toValue: 1,
        duration: 400,
        useNativeDriver: false,
      }).start();
    } else {
      Animated.timing(opacityAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: false,
      }).start();
    }
  }, [opacityAnim, viewState]);

  const startAnimationOpacity1 = useCallback(() => {
    if (view === true) {
      Animated.timing(opacityAnim1, {
        toValue: 1,
        duration: 400,
        useNativeDriver: false,
      }).start();
    } else {
      Animated.timing(opacityAnim1, {
        toValue: 0,
        duration: 300,
        useNativeDriver: false,
      }).start();
    }
  }, [opacityAnim1, view]);

  return (
    <ScrollView
      contentContainerStyle={styles.contentContainerStyle}
      showsVerticalScrollIndicator={false}
      style={styles.container}>
      <StaticsHealthItem
        title={notificationData.title}
        description={notificationData.description}
        Svg={notificationData.Svg}
      />
      {showChart1 && (
        <StaticsHealthChart
          svg={<SvgBlood width={12} height={16} />}
          glycemicIndex={89}
          percentage={73}
          onSeeGoals={onSeeGoals}
          onPress={onChart1}
          onEditGoal={onEditGoal}
        />
      )}
      {showChart2 && (
        <Animated.View style={opacityStyle}>
          <StaticsHealthChart
            svg={<SvgScale color={colors.secondRed} />}
            glycemicIndex={89}
            percentage={25}
            onSeeGoals={onSeeGoals}
            onPress={onChart2}
          />
        </Animated.View>
      )}
    </ScrollView>
  );
});
export default Day;

const styles = ScaledSheet.create({
  container: {
    flex: 1,
    height: '100%',
    backgroundColor: colors.pageBackGround,
    paddingTop: 24,
  },
  staticsHealthChart: {
    marginBottom: 16,
  },
  contentContainerStyle: {
    paddingBottom: Platform.OS === 'ios' ? getStatusBarHeight() + 100 : 100,
  },
});
