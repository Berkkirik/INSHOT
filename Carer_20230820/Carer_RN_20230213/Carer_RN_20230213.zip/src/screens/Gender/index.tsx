import React, { memo, useCallback } from "react";
import { Text, View, StyleSheet, ImageRequireSource } from "react-native";
import Carousel from "react-native-reanimated-carousel";
import {
  animatedStyles,
  scrollInterpolator,
} from "@screens/Gender/components/Animation";
import colors from "@utils/colors";
import FONTS from "@utils/fonts/index";

import ButtonPrimary from "@components/ButtonPrimary";
import { useNavigation } from "@react-navigation/native";
import ROUTES from "@utils/routes";
import { widthScreen } from "@utils/dimensions";
import GenderItem from "./components/GenderItem";
import { Images } from "@assets/index";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface GenderItemProps {
  image?: ImageRequireSource;
  title?: string;
}

const ITEM_WIDTH = Math.round(widthScreen * 0.55);

const data: GenderItemProps[] = [
  {
    image: Images.other,
    title: "Other",
  },
  {
    image: Images.woman,
    title: "Woman",
  },
  {
    image: Images.man,
    title: "Man",
  },
];

const Gender = memo(() => {
  const { navigate } = useNavigation();
  const { bottom } = useSafeAreaInsets();

  const onBirthDay = useCallback(() => {
    navigate(ROUTES.BirthDay);
  }, []);

  const renderItem = ({ item }: GenderItemProps) => {
    return <GenderItem {...item} />;
  };

  return (
    <View style={styles.container}>
      <Carousel
        data={data || []}
        renderItem={renderItem}
        firstItem={1}
        sliderWidth={widthScreen}
        itemWidth={ITEM_WIDTH}
        containerCustomStyle={styles.carouselContainer}
        inactiveSlideShift={0}
        scrollInterpolator={scrollInterpolator}
        slideInterpolatedStyle={animatedStyles}
        activeSlideAlignment={"center"}
        inactiveSlideOpacity={0.1}
      />
      <Text style={styles.txtIam}>I am a</Text>
      <View style={[styles.buttonView, { paddingBottom: bottom + 24 }]}>
        <ButtonPrimary title={"Next"} onPress={onBirthDay} />
      </View>
    </View>
  );
});

export default Gender;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
  },
  carouselContainer: {
    paddingTop: 100,
    backgroundColor: colors.white,
  },
  txtIam: {
    position: "absolute",
    top: 40,
    alignSelf: "center",
    fontFamily: FONTS.HIND.SemiBold,
    fontWeight: "600",
    fontSize: 24,
    lineHeight: 32,
    color: colors.bluePrimary,
  },
  buttonView: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    paddingTop: 8,
    paddingHorizontal: 40,
    backgroundColor: colors.white,
  },
});
