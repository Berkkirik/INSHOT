import React, { memo } from "react";
import {
  Text,
  View,
  StyleSheet,
  Image,
  ImageRequireSource,
} from "react-native";
import FONTS from "@utils/fonts";

import colors from "@utils/colors";

interface GenderItemProps {
  image?: ImageRequireSource;
  title?: string;
}

const GenderItem = memo(({ image, title }: GenderItemProps) => {
  return (
    <View>
      {image && <Image source={image} style={styles.image} />}
      <Text style={styles.txtGender}>{title}</Text>
    </View>
  );
});

export default GenderItem;

const styles = StyleSheet.create({
  svg: {
    marginLeft: 50,
  },
  txtGender: {
    fontFamily: FONTS.HIND.Regular,
    fontSize: 32,
    lineHeight: 48,
    color: colors.semiBlack,
    textAlign: "center",
    marginTop: 40,
  },
  image: {
    marginLeft: 50,
  },
});
