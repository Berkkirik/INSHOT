import React, {memo, useCallback, useState} from 'react';
import {View, FlatList} from 'react-native';
import {ScaledSheet} from 'react-native-size-matters';
import colors from '@utils/colors';
import DoctorItem from '@components/DoctorItem';
import keyExtractor from '@utils/keyExtractor';

import ROUTES from '@utils/routes';
import {ConfirmDialog} from 'react-native-simple-dialogs';
import FONTS from '@utils/fonts';
import {NavigationProp, useNavigation} from '@react-navigation/native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {RootStackParamsList} from '@navigation/type-navigation';

const LIST_DOCTORS_DATA = [
  {
    imgDoctor: require('@assets/ResultFindDoctor/01.png'),
    doctorName: 'Angel Manning',
    specialized: 'Cardiologist',
    rating: '5.0',
    location: 'Newyork, United States',
  },
  {
    imgDoctor: require('@assets/ResultFindDoctor/02.png'),
    doctorName: 'Jeremy Porter',
    specialized: 'Cardiologist',
    rating: '5.0',
    location: 'Newyork, United States',
  },
  {
    imgDoctor: require('@assets/ResultFindDoctor/03.png'),
    doctorName: 'Cecelia Boone',
    specialized: 'Cardiologist',
    rating: '5.0',
    location: 'Newyork, United States',
  },
  {
    imgDoctor: require('@assets/ResultFindDoctor/04.png'),
    doctorName: 'Jesse Burgess',
    specialized: 'Cardiologist',
    rating: '5.0',
    location: 'Newyork, United States',
  },
  {
    imgDoctor: require('@assets/ResultFindDoctor/01.png'),
    doctorName: 'Angel Manning',
    specialized: 'Cardiologist',
    rating: '5.0',
    location: 'Newyork, United States',
  },
];

const ListAll = memo(() => {
  const {navigate} = useNavigation<NavigationProp<RootStackParamsList>>();
  const {top, bottom} = useSafeAreaInsets();
  const [listDoctorsData, setListDoctorsData] = useState(LIST_DOCTORS_DATA);

  const onDoctorProfile = useCallback(() => {
    navigate('DoctorProfile');
  }, []);

  const onCallDoctor = useCallback(() => {
    navigate('CallDoctor');
  }, []);

  const onDoctorMessage = useCallback(() => {
    navigate('DoctorMessage');
  }, []);

  const onLocation = useCallback(() => {
    navigate('MapsDoctors');
  }, []);

  const renderItem = useCallback(
    ({item}) => {
      const {imgDoctor, doctorName, specialized, rating, location} = item;
      return (
        <DoctorItem
          activeRemove={true}
          imgDoctor={imgDoctor}
          doctorName={doctorName}
          specialized={specialized}
          rating={rating}
          location={location}
          onPress={onDoctorProfile}
          onCall={onCallDoctor}
          onMessage={onDoctorMessage}
          onLocation={onLocation}
        />
      );
    },
    [onDoctorProfile, onDoctorMessage, onCallDoctor],
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={listDoctorsData}
        renderItem={renderItem}
        keyExtractor={keyExtractor}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.contentContainerStyle,
          {top: top + 80, paddingBottom: bottom + 180},
        ]}
      />
      {/* <ConfirmDialog
        dialogStyle={styles.dialogStyle}
        title="Delete Doctor"
        message="Do you want delete doctor
        Jose Holland on list?"
        visible={visible}
        messageStyle={styles.messageStyle}
        onTouchOutside={onTouchOutside}
        positiveButton={{
          title: 'Done',
          onPress: () => setVisible(false),
          style: styles.positiveButton,
          titleStyle: styles.txtPositiveButton,
        }}
        negativeButton={{
          title: 'Cancel',
          onPress: () => setVisible(false),
          style: styles.negativeButton,
          titleStyle: styles.txtNegativeButton,
        }}
      /> */}
    </View>
  );
});
export default ListAll;

const styles = ScaledSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.pageBackGround,
  },
  contentContainerStyle: {
    paddingRight: 24,
  },
  txtTitleAlert: {
    fontFamily: FONTS.HIND.SemiBold,
    fontWeight: '500',
    fontSize: 18,
    lineHeight: 29,
    color: colors.semiBlack,
  },
});
