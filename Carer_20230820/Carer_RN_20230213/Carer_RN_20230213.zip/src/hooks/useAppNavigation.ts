import {RootStackParamsList} from '@navigation/type-navigation';
import {useNavigation, NavigationProp} from '@react-navigation/native';
const useAppNavigation = () => {
  const {goBack, navigate} =
    useNavigation<NavigationProp<RootStackParamsList>>();
  return {goBack, navigate};
};

export default useAppNavigation;
